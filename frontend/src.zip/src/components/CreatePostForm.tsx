'use client'

import { useState } from 'react'
import { postsAPI, Post } from '@/lib/api'
import { Button } from '@/components/ui/index'

export function CreatePostForm({ onCreated }: { onCreated: (post: Post) => void }) {
  const [content, setContent] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim()) return
    setIsSubmitting(true)
    setError(null)
    try {
      const res = await postsAPI.create(content.trim())
      onCreated(res.data)
      setContent('')
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to create post')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white border border-[#e2e8f0] rounded-[16px] p-[20px] shadow-[0_1px_2px_rgba(0,0,0,0.05)] mb-[24px]">
      {error && (
        <div className="py-[10px] px-[14px] bg-[#fef2f2] border border-[#fee2e2] rounded-[8px] text-[#991b1b] text-[13px] font-[500] mb-[12px]">
          {error}
        </div>
      )}
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="What's on your mind?"
        rows={3}
        maxLength={10000}
        className="w-full resize-none border border-[#e2e8f0] rounded-[8px] p-[12px] text-[14px] outline-none transition-all focus:border-[#6366f1] focus:shadow-[0_0_0_3px_rgba(99,102,241,0.1)] mb-[12px]"
      />
      <div className="flex justify-end">
        <Button type="submit" disabled={isSubmitting || !content.trim()}>
          {isSubmitting ? 'Posting...' : 'Post'}
        </Button>
      </div>
    </form>
  )
}
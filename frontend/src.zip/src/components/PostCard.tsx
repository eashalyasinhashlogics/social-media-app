'use client'

import { useState } from 'react'
import { postsAPI, Post } from '@/lib/api'

function timeAgo(dateString: string): string {
  const diffMs = Date.now() - new Date(dateString).getTime()
  const diffMins = Math.floor(diffMs / 60000)
  if (diffMins < 1) return 'just now'
  if (diffMins < 60) return `${diffMins}m ago`
  const diffHours = Math.floor(diffMins / 60)
  if (diffHours < 24) return `${diffHours}h ago`
  const diffDays = Math.floor(diffHours / 24)
  return `${diffDays}d ago`
}

interface PostCardProps {
  post: Post
  currentUserId: string
  onUpdated: (post: Post) => void
  onDeleted: (postId: string) => void
}

export function PostCard({ post, currentUserId, onUpdated, onDeleted }: PostCardProps) {
  const isOwner = post.author_id === currentUserId
  const [menuOpen, setMenuOpen] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [editContent, setEditContent] = useState(post.content)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSaveEdit = async () => {
    if (!editContent.trim()) return
    setBusy(true)
    setError(null)
    try {
      const res = await postsAPI.update(post.id, editContent.trim())
      onUpdated(res.data)
      setIsEditing(false)
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to update post')
    } finally {
      setBusy(false)
    }
  }

  const handleDelete = async () => {
    if (!window.confirm('Delete this post? This cannot be undone.')) return
    setBusy(true)
    try {
      await postsAPI.delete(post.id)
      onDeleted(post.id)
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to delete post')
      setBusy(false)
    }
  }

  const handleToggleArchive = async () => {
    setBusy(true)
    setError(null)
    try {
      const res = post.status === 'archived'
        ? await postsAPI.unarchive(post.id)
        : await postsAPI.archive(post.id)
      onUpdated(res.data)
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to update post')
    } finally {
      setBusy(false)
      setMenuOpen(false)
    }
  }

  return (
    <div className="bg-white border border-[#e2e8f0] rounded-[16px] p-[20px] shadow-[0_1px_2px_rgba(0,0,0,0.05)] mb-[16px] relative">
      <div className="flex items-start justify-between mb-[10px]">
        <div className="flex items-center gap-[10px]">
          <div className="w-[36px] h-[36px] rounded-full bg-[linear-gradient(135deg,#6366f1,#7c3aed)] flex items-center justify-center text-white text-[14px] font-[700]">
            {(post.author_username || '?').charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="text-[14px] font-[600] text-[#1a202c]">{post.author_username || 'Unknown user'}</div>
            <div className="text-[12px] text-[#9ca3af] flex items-center gap-[6px]">
              {timeAgo(post.created_at)}
              {post.status === 'archived' && (
                <span className="bg-[#f3f4f6] text-[#6b7280] text-[10px] font-[600] px-[6px] py-[2px] rounded-full">Archived</span>
              )}
            </div>
          </div>
        </div>

        {isOwner && (
          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              disabled={busy}
              className="text-[#9ca3af] hover:text-[#374151] bg-transparent border-none cursor-pointer p-[4px] text-[18px] leading-none"
              aria-label="Post options"
            >
              ⋯
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-[28px] bg-white border border-[#e2e8f0] rounded-[8px] shadow-[0_4px_12px_rgba(0,0,0,0.1)] py-[4px] z-10 min-w-[140px]">
                <button
                  onClick={() => { setIsEditing(true); setMenuOpen(false) }}
                  className="w-full text-left px-[14px] py-[8px] text-[13px] text-[#374151] hover:bg-[#f8fafc] bg-transparent border-none cursor-pointer"
                >
                  Edit
                </button>
                <button
                  onClick={handleToggleArchive}
                  className="w-full text-left px-[14px] py-[8px] text-[13px] text-[#374151] hover:bg-[#f8fafc] bg-transparent border-none cursor-pointer"
                >
                  {post.status === 'archived' ? 'Unarchive' : 'Archive'}
                </button>
                <button
                  onClick={handleDelete}
                  className="w-full text-left px-[14px] py-[8px] text-[13px] text-[#ef4444] hover:bg-[#fef2f2] bg-transparent border-none cursor-pointer"
                >
                  Delete
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {error && (
        <div className="py-[8px] px-[12px] bg-[#fef2f2] border border-[#fee2e2] rounded-[8px] text-[#991b1b] text-[12px] font-[500] mb-[10px]">
          {error}
        </div>
      )}

      {isEditing ? (
        <div>
          <textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            rows={3}
            maxLength={10000}
            className="w-full resize-none border border-[#e2e8f0] rounded-[8px] p-[10px] text-[14px] outline-none focus:border-[#6366f1] mb-[8px]"
          />
          <div className="flex gap-[8px] justify-end">
            <button
              onClick={() => { setIsEditing(false); setEditContent(post.content) }}
              disabled={busy}
              className="px-[14px] py-[6px] text-[13px] font-[600] text-[#374151] bg-white border border-[#e2e8f0] rounded-[8px] cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveEdit}
              disabled={busy || !editContent.trim()}
              className="px-[14px] py-[6px] text-[13px] font-[600] text-white bg-[#6366f1] border-none rounded-[8px] cursor-pointer disabled:opacity-60"
            >
              Save
            </button>
          </div>
        </div>
      ) : (
        <p className="text-[14px] text-[#1a202c] leading-[1.5] whitespace-pre-wrap">{post.content}</p>
      )}

      <div className="flex items-center gap-[20px] mt-[14px] pt-[12px] border-t border-[#f1f5f9] text-[13px] text-[#64748b]">
        <span>❤ {post.like_count}</span>
        <span>💬 {post.comment_count}</span>
        <span>↻ {post.share_count}</span>
      </div>
    </div>
  )
}